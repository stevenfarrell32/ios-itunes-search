//
//  SearchResultsTableViewController.swift
//  iTunes Search
//
//  Created by Lambda_School_Loaner_151 on 9/17/19.
//  Copyright © 2019 Lambda_School_Loaner_151. All rights reserved.
//

import UIKit


class SearchResultsTableViewController: UITableViewController {
    
    var searchResults: [SearchResult] = []
    
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var searchBar: UISearchBar!
    
    let searchResultsController = SearchResultController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchBar.delegate = self
    }

    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return searchResults.count
    }
// this is where we have configured each cell one by one to give it the information we need
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SearchResultCell", for: indexPath)
        let searchResult = searchResults[indexPath.row]
        cell.textLabel?.text = searchResult.trackName
        cell.detailTextLabel?.text = searchResult.artistName // takes the string we made in our searchResult.swift and puts it into thelabel..same for line 34
        return cell
        }


}

extension SearchResultsTableViewController: UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        print("This is the error")
        guard let searchTerm = searchBar.text else {
            print("No text found in the searchbar")
            return
        }
        searchResultsController.performSearch(with: searchTerm) { (SearchResults, Error) in
            if let error = Error {
                print(error.localizedDescription)
                return
            }
            // in this we are calling the property of what we are trying to get to
            if let mySearchResults = SearchResults {
                self.searchResults = mySearchResults.results
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            }
        }
    }
}


