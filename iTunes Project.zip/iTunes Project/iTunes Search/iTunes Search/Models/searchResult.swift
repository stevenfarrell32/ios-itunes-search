//
//  searchResult.swift
//  iTunes Search
//
//  Created by Lambda_School_Loaner_151 on 9/16/19.
//  Copyright © 2019 Lambda_School_Loaner_151. All rights reserved.
//

import Foundation
// this is the parent object that we will use to unwrap all of our information when we call it in our table view controller
struct SearchResults: Codable {
    let results: [SearchResult]
}
// this struct contains the information of whats in the array in our Parent struct of SearchResults
struct SearchResult: Codable {
    var trackName: String
    var artistName: String
}

