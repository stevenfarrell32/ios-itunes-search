//
//  SearchResultController.swift
//  iTunes Search
//
//  Created by Lambda_School_Loaner_151 on 9/16/19.
//  Copyright © 2019 Lambda_School_Loaner_151. All rights reserved.
//

import Foundation

class SearchResultController {
    let baseURL = URL(string: "https://itunes.apple.com")!
    enum HTTPMethod: String {
        case get = "GET"
        case put = "PUT"
        case post = "POST"
        case delete = "DELETE"
    }
    // function performs the full search returning the search results or an error
    func performSearch(with searchTerm: String, completion: @escaping (SearchResults?, Error?) -> ()) {
        
        var components = URLComponents()
        let queryItem = URLQueryItem(name: "term", value: searchTerm.lowercased())
        let nameEntity = URLQueryItem(name: "entity", value: "musicTrack")
        components.scheme = "https"
        components.host = "itunes.apple.com"
        components.path = "/search"
        components.queryItems = [queryItem, nameEntity]
        
        guard let requestURL = components.url else {
            print("Request URL is nil")
            return
        }
        print(requestURL)
        // the URLRequest is our object, in order for the value of this to exist, it has to have a value. In this case our value is "url". The request is asking can we get this information, and it is asking do we have a url to even get
        var request = URLRequest(url: requestURL)
        request.httpMethod = HTTPMethod.get.rawValue
        // line 35 we are assiging our value whatever method we need it to do with our URL i.e. get from the url or delete from the url etc
        
        // the data task is going to perform the task of communicating with the server, based off of what we have defined from the enum
        URLSession.shared.dataTask(with: request) {data, _, error in
            if let error = error {
                print("Error fetching data: \(error)")
                return
            }
            guard let data = data else {
                print("No data returned from data task")
                return
            }
            // do catch is similar to if let statements. IN a real sense do is like a rock climbing instructor telling me to take my hand from one rock to the next (perform my logic) if I fall I have a net to catch me (my error statement)
            let jsonDecoder = JSONDecoder()
            do {
                let data = try jsonDecoder.decode(SearchResults.self, from: data)
                print(data.results)
                completion(data, nil) // we try our decoder, if it gets past that we pass in data and there is no error. If our try fails, we skip our first completion and go to the fail(the safety net)
            } catch {
                completion(nil, error) // this is the safety net when there is no data so therefore we return the error (fall into the net)
                return
        }
//            completion(SearchResults, error)
    }.resume()
    
}

}
